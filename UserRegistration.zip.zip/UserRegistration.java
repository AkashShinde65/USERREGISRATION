import java.sql.*;
import java.util.Scanner;

public class UserRegistration {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get user inputs
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter City: ");
        String city = scanner.nextLine();

        System.out.print("Enter Email ID: ");
        String email = scanner.nextLine();

        // Save to database
        addUser(firstName, lastName, city, email);

        scanner.close();
    }

    public static void addUser(String firstName, String lastName, String city, String email) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            // Database connection
            String url = "jdbc:mysql://localhost:3306/akashdb";
            String user = "root"; // 🔁 Change if your MySQL username is different
            String password = "1210"; // 🔁 Change this to your MySQL password

            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);

            // SQL query
            String sql = "INSERT INTO users (first_name, last_name, city, email) VALUES (?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, city);
            ps.setString(4, email);

            // Execute
            ps.executeUpdate();
            System.out.println("✅ User added successfully!");

        } catch (Exception e) {
            System.out.println("❌ Something went wrong!");
            e.printStackTrace();
        } finally {
            try {
                if (ps != null)
                    ps.close();
                if (conn != null)
                    conn.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
